import serial
import time

# Connect to Arduino (adjust COM port if needed)
ser = serial.Serial('COM5', 9600)
time.sleep(2)  # Wait for Arduino to initialize

try:
    while True:
        pot_value = ser.readline().decode().strip()
        if pot_value.isdigit():  # Check if valid number
            pot_value = int(pot_value)
            print("Potentiometer Value:", pot_value)

            # Send command to Arduino
            if pot_value > 512:
                ser.write(b'1')  # Turn LED ON
            else:
                ser.write(b'0')  # Turn LED OFF

except KeyboardInterrupt:
    ser.close()
    print("Serial connection closed.")
