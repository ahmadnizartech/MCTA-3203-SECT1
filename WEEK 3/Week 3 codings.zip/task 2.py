import serial
import matplotlib.pyplot as plt
import time
import threading

# --- Serial Connection ---
ser = serial.Serial('COM5', 9600)
time.sleep(2)  # Wait for Arduino to initialize

# --- Real-time Plot Setup ---
plt.ion()
fig, ax = plt.subplots()
x_vals, pot_vals, servo_vals = [], [], []

running = True

def listen_for_quit():
    """Listen for 'q' key input to stop Arduino and end the program."""
    global running
    while running:
        cmd = input("Press 'q' to stop: ")
        if cmd.lower() == 'q':
            ser.write(b'q')  # Tell Arduino to stop
            running = False
            break

# Run quit listener in background
thread = threading.Thread(target=listen_for_quit)
thread.start()

try:
    while running:
        line = ser.readline().decode().strip()
        if not line:
            continue
        try:
            pot_str, servo_str = line.split(',')
            pot_value = int(pot_str)
            servo_angle = int(servo_str)
            print(f"Potentiometer: {pot_value} | Servo Angle: {servo_angle}")

            # Append values for plotting
            x_vals.append(len(x_vals))
            pot_vals.append(pot_value)
            servo_vals.append(servo_angle)

            # Update live plot
            ax.clear()
            ax.plot(x_vals, pot_vals, label="Potentiometer")
            ax.plot(x_vals, servo_vals, label="Servo Angle")
            ax.set_xlabel("Time (samples)")
            ax.set_ylabel("Value")
            ax.set_title("Real-time Potentiometer and Servo Data")
            ax.legend()
            plt.pause(0.1)

        except ValueError:
            continue

except KeyboardInterrupt:
    pass

finally:
    running = False
    ser.close()
    plt.ioff()
    plt.show()
    print("Serial connection closed.")
