import serial
import time

# Change COM5 to your Arduino's port
ser = serial.Serial('COM5', 9600)
time.sleep(2)  # Wait for Arduino to reset

try:
    while True:
        angle = input("Enter servo angle (0-180 deg, or 'q' to quit): ")

        if angle.lower() == 'q':
            break

        if angle.isdigit():
            val = int(angle)
            if 0 <= val <= 180:
                ser.write((angle + '\n').encode())  # Send angle to Arduino
            else:
                print("Angle must be between 0 and 180.")
        else:
            print("Please enter a valid number.")

except KeyboardInterrupt:
    pass

finally:
    ser.close()
    print("Serial connection closed.")
